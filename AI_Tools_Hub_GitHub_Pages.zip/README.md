# AI Tools Hub

A responsive single-page starter for GitHub Pages.

## Included
- Professional dark blue/purple landing page inspired by the reference mockup
- Responsive tool navigation and step-by-step guide
- Browser speech synthesis for voice playback (audio file export is not guaranteed)
- Background removal using a browser-side open-source library loaded from a CDN
- Prompt preparation for AI image generation (requires a real provider/API for image output)
- Experimental browser-based video clip export (browser/codec dependent)
- Gallery, download, delete and clear controls
- No secret API keys included

## Publish on GitHub Pages from a phone
1. Create/open your GitHub repository.
2. Add a file named `index.html` at the repository root and paste the supplied HTML.
3. Commit the file.
4. Open repository **Settings → Pages**.
5. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
6. Wait for the published URL shown in Settings → Pages.

## Important limits
GitHub Pages is static hosting. The AI Image Generator only prepares a prompt until an image API is connected. For real image generation and downloadable AI voice, use a provider with an API and call it from a secure backend/serverless function. Never put private API keys in this public HTML. Background-removal and video features depend on browser support, memory, internet and codecs.
